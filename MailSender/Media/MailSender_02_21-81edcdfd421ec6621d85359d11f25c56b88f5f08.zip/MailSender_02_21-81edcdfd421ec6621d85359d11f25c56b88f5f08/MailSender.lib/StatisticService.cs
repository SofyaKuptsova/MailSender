﻿namespace MailSender.lib
{
    public class StatisticService
    {

    }
}