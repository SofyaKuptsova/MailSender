﻿namespace MailSender.lib
{
    public class DbService
    {

    }
}