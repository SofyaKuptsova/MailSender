﻿namespace MailSender.Models.Base
{
    public abstract class Entity
    {
        public int Id { get; set; }
    }
}
