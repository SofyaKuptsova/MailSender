﻿namespace MailSender.lib
{
    public class MailSchedulerService
    {
    }
}